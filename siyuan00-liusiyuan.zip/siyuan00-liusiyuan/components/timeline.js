class ResearchTimeline extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this._selectedYear = null;
  }

  static get observedAttributes() {
    return ['selected-year'];
  }

  attributeChangedCallback(name, oldValue, newValue) {
    if (name === 'selected-year') {
      this._selectedYear = newValue;
      this.updateSelection();
    }
  }

  connectedCallback() {
    this.render();
    this.addEventListeners();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          width: 100%;
        }
        
        .timeline {
          position: relative;
          padding-left: 2rem;
        }
        
        .timeline::before {
          content: '';
          position: absolute;
          left: 7px;
          top: 0;
          bottom: 0;
          width: 2px;
          background: linear-gradient(to bottom, rgba(99, 102, 241, 0.5), rgba(6, 182, 212, 0.2));
        }
        
        .timeline-item {
          position: relative;
          padding-bottom: 2rem;
          cursor: pointer;
          transition: all 0.3s;
        }
        
        .timeline-item:last-child {
          padding-bottom: 0;
        }
        
        .timeline-dot {
          position: absolute;
          left: -1.5rem;
          top: 0.25rem;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: rgba(15, 23, 42, 0.8);
          border: 2px solid #6366f1;
          transition: all 0.3s;
          z-index: 1;
        }
        
        .timeline-item:hover .timeline-dot,
        .timeline-item.active .timeline-dot {
          background: #6366f1;
          box-shadow: 0 0 20px rgba(99, 102, 241, 0.6);
          transform: scale(1.2);
        }
        
        .timeline-content {
          background: rgba(15, 23, 42, 0.4);
          border: 1px solid rgba(255, 255, 255, 0.05);
          border-radius: 0.75rem;
          padding: 1rem;
          transition: all 0.3s;
        }
        
        .timeline-item:hover .timeline-content,
        .timeline-item.active .timeline-content {
          background: rgba(99, 102, 241, 0.1);
          border-color: rgba(99, 102, 241, 0.3);
          transform: translateX(4px);
        }
        
        .timeline-year {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.875rem;
          font-weight: 600;
          color: #818cf8;
          margin-bottom: 0.25rem;
        }
        
        .timeline-title {
          font-size: 1rem;
          font-weight: 600;
          color: #f1f5f9;
          margin-bottom: 0.5rem;
        }
        
        .timeline-desc {
          font-size: 0.875rem;
          color: #94a3b8;
          line-height: 1.5;
        }
        
        .timeline-meta {
          display: flex;
          gap: 1rem;
          margin-top: 0.75rem;
          font-size: 0.75rem;
          font-family: 'JetBrains Mono', monospace;
          color: #64748b;
        }
        
        .filter-hint {
          margin-top: 1rem;
          padding: 0.75rem;
          background: rgba(6, 182, 212, 0.1);
          border: 1px solid rgba(6, 182, 212, 0.2);
          border-radius: 0.5rem;
          font-size: 0.875rem;
          color: #22d3ee;
          text-align: center;
          font-family: 'JetBrains Mono', monospace;
        }
      </style>
      
      <div class="timeline">
        <div class="timeline-item" data-year="2024">
          <div class="timeline-dot"></div>
          <div class="timeline-content">
            <div class="timeline-year">2024</div>
            <div class="timeline-title">IEEE Big Data Cup</div>
            <div class="timeline-desc">Suicide risk detection project with MDF-FOF framework. Competition win and publication.</div>
            <div class="timeline-meta">
              <span>1st Place</span>
              <span>IEEE BigData</span>
            </div>
          </div>
        </div>
        
        <div class="timeline-item" data-year="2025">
          <div class="timeline-dot"></div>
          <div class="timeline-content">
            <div class="timeline-year">2025</div>
            <div class="timeline-title">CVPR Demo & Infi-Med</div>
            <div class="timeline-desc">BreakBeat dance segmentation demo at CVPR. Infi-Med published on arXiv for low-resource medical MLLMs.</div>
            <div class="timeline-meta">
              <span>CVPR</span>
              <span>arXiv</span>
            </div>
          </div>
        </div>
        
        <div class="timeline-item active" data-year="current">
          <div class="timeline-dot"></div>
          <div class="timeline-content">
            <div class="timeline-year">Current</div>
            <div class="timeline-title">Hybrid Attention & Latent CoT</div>
            <div class="timeline-desc">Working with Tsinghua NLP Lab & ModelBest on linear attention mechanisms and compressed reasoning states for Qwen3.</div>
            <div class="timeline-meta">
              <span>Tsinghua</span>
              <span>ModelBest</span>
            </div>
          </div>
        </div>
      </div>
      
      <div class="filter-hint">
        Click timeline items to filter publications
      </div>
    `;
  }

  addEventListeners() {
    const items = this.shadowRoot.querySelectorAll('.timeline-item');
    items.forEach(item => {
      item.addEventListener('click', () => {
        const year = item.getAttribute('data-year');
        
        // Toggle selection
        if (this._selectedYear === year) {
          this._selectedYear = null;
          item.classList.remove('active');
        } else {
          items.forEach(i => i.classList.remove('active'));
          item.classList.add('active');
          this._selectedYear = year;
        }
        
        // Dispatch event for React to handle
        this.dispatchEvent(new CustomEvent('timeline-select', {
          detail: { year: this._selectedYear },
          bubbles: true,
          composed: true
        }));
      });
    });
  }

  updateSelection() {
    const items = this.shadowRoot.querySelectorAll('.timeline-item');
    items.forEach(item => {
      item.classList.toggle('active', item.getAttribute('data-year') === this._selectedYear);
    });
  }
}

customElements.define('research-timeline', ResearchTimeline);