class GlassCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    const hoverEffect = this.hasAttribute('hover') ? 'hover-lift' : '';
    const padding = this.getAttribute('padding') || '1.5rem';
    const className = this.getAttribute('class') || '';
    
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          width: 100%;
        }
        
        .card {
          background: rgba(15, 23, 42, 0.6);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 1rem;
          padding: ${padding};
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .card.hover-lift:hover {
          transform: translateY(-4px);
          box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.5);
          border-color: rgba(99, 102, 241, 0.3);
          background: rgba(15, 23, 42, 0.8);
        }
        
        .card.accent {
          border-left: 3px solid #6366f1;
        }
        
        .card.cyan {
          border-left: 3px solid #06b6d4;
        }
      </style>
      
      <div class="card ${hoverEffect} ${className}">
        <slot></slot>
      </div>
    `;
  }
}

customElements.define('glass-card', GlassCard);