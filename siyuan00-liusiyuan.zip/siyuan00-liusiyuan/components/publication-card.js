class PublicationCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this._expanded = false;
  }

  static get observedAttributes() {
    return ['title', 'venue', 'year', 'expanded'];
  }

  connectedCallback() {
    this.render();
    this.addEventListeners();
  }

  render() {
    const title = this.getAttribute('title') || 'Publication Title';
    const venue = this.getAttribute('venue') || 'Venue';
    const year = this.getAttribute('year') || '2024';
    const tags = this.getAttribute('tags') ? this.getAttribute('tags').split(',') : [];
    
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          width: 100%;
          margin-bottom: 1rem;
        }
        
        .pub-card {
          background: rgba(15, 23, 42, 0.6);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 1rem;
          overflow: hidden;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .pub-card:hover {
          border-color: rgba(99, 102, 241, 0.3);
          box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
        }
        
        .pub-header {
          padding: 1.5rem;
          cursor: pointer;
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 1rem;
        }
        
        .pub-meta {
          flex: 1;
        }
        
        .pub-title {
          font-size: 1.125rem;
          font-weight: 600;
          color: #f1f5f9;
          margin-bottom: 0.5rem;
          line-height: 1.4;
        }
        
        .pub-venue {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.875rem;
          color: #818cf8;
          margin-bottom: 0.75rem;
        }
        
        .pub-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }
        
        .tag {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.75rem;
          padding: 0.25rem 0.75rem;
          background: rgba(6, 182, 212, 0.1);
          border: 1px solid rgba(6, 182, 212, 0.2);
          border-radius: 9999px;
          color: #22d3ee;
        }
        
        .expand-btn {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 0.5rem;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #94a3b8;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        
        .expand-btn:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #818cf8;
          border-color: rgba(99, 102, 241, 0.3);
        }
        
        .expand-icon {
          transition: transform 0.3s;
        }
        
        .expand-icon.rotated {
          transform: rotate(180deg);
        }
        
        .pub-details {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease-out;
          border-top: 1px solid transparent;
        }
        
        .pub-details.expanded {
          max-height: 500px;
          border-top-color: rgba(255, 255, 255, 0.1);
        }
        
        .details-content {
          padding: 1.5rem;
        }
        
        .details-title {
          font-size: 0.875rem;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 0.75rem;
        }
        
        .details-list {
          list-style: none;
          padding: 0;
          margin: 0 0 1.5rem 0;
        }
        
        .details-list li {
          position: relative;
          padding-left: 1.25rem;
          margin-bottom: 0.5rem;
          font-size: 0.875rem;
          color: #cbd5e1;
          line-height: 1.6;
        }
        
        .details-list li::before {
          content: '›';
          position: absolute;
          left: 0;
          color: #6366f1;
          font-weight: bold;
        }
        
        .action-buttons {
          display: flex;
          gap: 0.75rem;
        }
        
        .btn {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border-radius: 0.5rem;
          font-size: 0.875rem;
          font-weight: 500;
          text-decoration: none;
          transition: all 0.2s;
          font-family: 'JetBrains Mono', monospace;
        }
        
        .btn-primary {
          background: rgba(99, 102, 241, 0.2);
          border: 1px solid rgba(99, 102, 241, 0.3);
          color: #818cf8;
        }
        
        .btn-primary:hover {
          background: rgba(99, 102, 241, 0.3);
          transform: translateY(-1px);
        }
        
        .btn-secondary {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #94a3b8;
        }
        
        .btn-secondary:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #e2e8f0;
        }
      </style>
      
      <div class="pub-card">
        <div class="pub-header" onclick="this.getRootNode().host.toggle()">
          <div class="pub-meta">
            <div class="pub-title">${title}</div>
            <div class="pub-venue">${venue} • ${year}</div>
            <div class="pub-tags">
              ${tags.map(tag => `<span class="tag">${tag.trim()}</span>`).join('')}
            </div>
          </div>
          <button class="expand-btn" aria-label="Toggle details">
            <svg class="expand-icon ${this._expanded ? 'rotated' : ''}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </button>
        </div>
        
        <div class="pub-details ${this._expanded ? 'expanded' : ''}">
          <div class="details-content">
            <div class="details-title">Contribution Highlights</div>
            <ul class="details-list">
              <slot name="contribution"></slot>
            </ul>
            
            <div class="action-buttons">
              <a href="#" class="btn btn-primary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                PDF
              </a>
              <a href="#" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                Code
              </a>
              <a href="#" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                Project
              </a>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  toggle() {
    this._expanded = !this._expanded;
    const details = this.shadowRoot.querySelector('.pub-details');
    const icon = this.shadowRoot.querySelector('.expand-icon');
    
    if (this._expanded) {
      details.classList.add('expanded');
      icon.classList.add('rotated');
    } else {
      details.classList.remove('expanded');
      icon.classList.remove('rotated');
    }
  }

  addEventListeners() {
    // Prevent button click from triggering header click twice
    const btn = this.shadowRoot.querySelector('.expand-btn');
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggle();
      });
    }
  }
}

customElements.define('publication-card', PublicationCard);