class ProfileSidebar extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          height: 100%;
        }
        
        .sidebar-container {
          height: 100%;
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        .profile-header {
          text-align: center;
          padding-bottom: 1.5rem;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .avatar {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          background: linear-gradient(135deg, #6366f1, #06b6d4);
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 1rem;
          font-size: 1.5rem;
          font-weight: 700;
          color: white;
          border: 2px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 0 30px rgba(99, 102, 241, 0.3);
        }
        
        .name {
          font-size: 1.25rem;
          font-weight: 700;
          color: #f1f5f9;
          margin-bottom: 0.25rem;
          letter-spacing: -0.025em;
        }
        
        .tagline {
          font-size: 0.875rem;
          color: #94a3b8;
          line-height: 1.4;
        }
        
        .status-card {
          background: rgba(99, 102, 241, 0.1);
          border: 1px solid rgba(99, 102, 241, 0.2);
          border-radius: 0.75rem;
          padding: 1rem;
          text-align: center;
        }
        
        .status-badge {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.75rem;
          font-weight: 600;
          color: #818cf8;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 0.5rem;
        }
        
        .status-dot {
          width: 8px;
          height: 8px;
          background: #22c55e;
          border-radius: 50%;
          animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        
        .status-text {
          font-size: 0.875rem;
          color: #e2e8f0;
          font-weight: 500;
        }
        
        .links-section {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }
        
        .section-title {
          font-size: 0.75rem;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-bottom: 0.5rem;
          padding-left: 0.5rem;
        }
        
        .link-item {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.625rem 0.75rem;
          border-radius: 0.5rem;
          color: #cbd5e1;
          text-decoration: none;
          font-size: 0.875rem;
          transition: all 0.2s;
          border: 1px solid transparent;
        }
        
        .link-item:hover {
          background: rgba(255, 255, 255, 0.05);
          border-color: rgba(255, 255, 255, 0.1);
          color: #f8fafc;
          transform: translateX(4px);
        }
        
        .link-icon {
          width: 18px;
          height: 18px;
          color: #6366f1;
        }
        
        .focus-widget {
          margin-top: auto;
          padding-top: 1.5rem;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .tag-cloud {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }
        
        .tag {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.75rem;
          padding: 0.375rem 0.75rem;
          background: rgba(6, 182, 212, 0.1);
          border: 1px solid rgba(6, 182, 212, 0.2);
          border-radius: 9999px;
          color: #22d3ee;
          transition: all 0.2s;
        }
        
        .tag:hover {
          background: rgba(6, 182, 212, 0.2);
          transform: translateY(-1px);
        }
        
        @media (max-width: 1024px) {
          .sidebar-container {
            padding-bottom: 1rem;
          }
          
          .focus-widget {
            margin-top: 0;
          }
        }
      </style>
      
      <div class="sidebar-container">
        <div class="profile-header">
          <div class="avatar">SL</div>
          <div class="name">Siyuan (Michelle) Liu</div>
<div class="tagline">Undergraduate at PolyU (CS & AI), Research Intern at Tsinghua NLP Lab</div>
        </div>
        
        <div class="status-card">
          <div class="status-badge">
            <span class="status-dot"></span>
            Open to Opportunities
          </div>
          <div class="status-text">Seeking Summer Research / Return Offer</div>
        </div>
        
        <div class="links-section">
          <div class="section-title">Connect</div>
          <a href="#" class="link-item">
            <svg class="link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
            GitHub
          </a>
          <a href="#" class="link-item">
            <svg class="link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            Google Scholar
          </a>
          <a href="CV_LIU_Siyuan_26_1.pdf" target="_blank" class="link-item">
            <svg class="link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
            Download CV
          </a>
          <a href="mailto:email@example.com" class="link-item">
            <svg class="link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
            Email
          </a>
        </div>
        
        <div class="focus-widget">
          <div class="section-title">Research Focus</div>
          <div class="tag-cloud">
            <span class="tag">Long-Context</span>
            <span class="tag">Hybrid Attention</span>
            <span class="tag">Latent CoT</span>
            <span class="tag">Multimodal Eval</span>
          </div>
        </div>
      </div>
    `;
  }
}

customElements.define('profile-sidebar', ProfileSidebar);