const { useState, useEffect } = React;

// Profile Data
const profileData = {
  hero: {
    name: "Siyuan (Michelle) Liu",
    tagline: "Undergraduate at PolyU (CS), Research Intern at Tsinghua NLP Lab",
bio: "Focusing on long-context efficiency and reasoning compression in large language models. Currently developing hybrid attention mechanisms and latent chain-of-thought architectures for next-generation multimodal systems. Passionate about bridging theoretical advances with real-world applications in medical AI and robotics evaluation.",
    badges: ["Seeking Summer Research", "Long-Context LLMs", "Hybrid/Linear Attention", "Latent CoT"]
  },
  researchInterests: [
    "Efficient attention mechanisms & long-context LLMs (hybrid / linear attention)",
    "Compressed reasoning states / Latent Chain-of-Thought (Latent CoT)",
    "Medical MLLMs + robust evaluation frameworks",
    "Multimodal benchmarking (LEGOBench) & VLM evaluation in robotics"
  ],
  education: {
    degree: "BSc in CS",
school: "HK PolyU",
    gpa: "3.61/4.3"
  },
  exchanges: [
    { school: "Stanford", focus: "CS" },
    { school: "University of Waterloo", focus: "Math" }
  ],
  coreFocus: [
    "Efficient Attention Mechanisms & Long-Context LLMs",
    "Recent Work: Developing Compressed Reasoning States (Latent CoT) for models like Qwen3",
    "Current: Working with Tsinghua NLP Lab & ModelBest on hybrid/linear attention and latent CoT"
  ],
  experience: [
    {
      role: "Research Intern",
      org: "Tsinghua NLP Lab",
      period: "Current",
      highlights: ["Development of MiniCPM and Xiaoda AI Assistant", "Hybrid/Linear Attention research", "Long-context efficiency optimization"]
    },
    {
      role: "Researcher",
      org: "ReaLLM-Labs",
      period: "2024",
      highlights: ["Robust medical evaluation frameworks", "Infi-Med: Low-Resource Medical MLLMs", "Clinical AI safety protocols"]
    }
  ],
publications: [
    {
      id: 1,
      title: "Infi-Med: Low-Resource Medical MLLMs",
      venue: "arXiv",
      year: "2025",
      tags: ["Medical AI", "MLLM", "Low-Resource"],
      contributions: [
        "Novel architecture for medical multimodal learning with minimal training data",
        "Comprehensive evaluation framework for clinical vision-language tasks",
        "State-of-the-art performance on medical VQA benchmarks"
      ],
      timelineYear: "2025"
    },
    {
      id: 2,
      title: "BreakBeat: AI-Powered Dance Segmentation",
      venue: "CVPR",
      year: "2025",
      tags: ["Computer Vision", "Dance AI", "Segmentation"],
      contributions: [
        "Real-time dance motion segmentation system",
        "Novel temporal attention mechanism for movement analysis",
        "Demo presentation at CVPR 2025"
      ],
      timelineYear: "2025"
    },
    {
      id: 3,
      title: "Suicide Risk Detection with MDF-FOF",
      venue: "IEEE Big Data",
      year: "2024",
      tags: ["NLP", "Mental Health", "Risk Assessment"],
      contributions: [
        "Multi-dimensional feature fusion framework for early risk detection",
        "1st Place IEEE BigData 2024 Cup solution",
        "Cross-lingual adaptation for mental health screening"
      ],
      timelineYear: "2024"
    }
  ],
  timeline: [
    { year: "2024", title: "IEEE Big Data Cup", desc: "Suicide risk detection project + competition win", type: "award" },
    { year: "2025", title: "BreakBeat CVPR demo", desc: "AI-Powered Dance Segmentation demonstration", type: "publication" },
    { year: "2025", title: "Infi-Med arXiv", desc: "Low-Resource Medical MLLMs publication", type: "publication" },
    { year: "current", title: "Hybrid Attention Research", desc: "Working with Tsinghua NLP Lab & ModelBest", type: "research" }
  ],
awards: [
    "1st Place IEEE BigData 2024 Cup",
    "HKSAR Talent Development Scholarship",
    "Dean's Honours List"
  ],
  techStack: {
    languages: ["C++", "Python"],
    ml: ["PyTorch", "Transformers", "vLLM"],
    tools: ["Cursor", "Figma"]
  },
  models: [
    {
      name: "Latent CoT",
      status: "Research",
      desc: "Developing compressed reasoning states for next-generation efficient LLMs."
    },
    {
      name: "Medical MLLM Eval",
      status: "Released",
      desc: "Robust evaluation framework for medical multimodal large language models."
    },
    {
      name: "MiniCPM Assistant",
      status: "Contributor",
      desc: "Contributed to development of efficient edge-side large language models."
    }
  ]
};

// Main App Component
function App() {
  const [selectedTimelineYear, setSelectedTimelineYear] = useState(null);
  const [expandedPubs, setExpandedPubs] = useState(new Set());
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Listen for timeline selection from web component
    const handleTimelineSelect = (e) => {
      if (e.detail && e.detail.year) {
        setSelectedTimelineYear(e.detail.year === selectedTimelineYear ? null : e.detail.year);
      }
    };
    
    document.addEventListener('timeline-select', handleTimelineSelect);
    return () => document.removeEventListener('timeline-select', handleTimelineSelect);
  }, [selectedTimelineYear]);

  const togglePub = (id) => {
    setExpandedPubs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const filteredPublications = selectedTimelineYear 
    ? profileData.publications.filter(pub => pub.timelineYear === selectedTimelineYear)
    : profileData.publications;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 relative overflow-x-hidden">
      {/* Background Effects */}
      <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-indigo-950/10 to-slate-950 pointer-events-none" />
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 glass-strong border-b border-white/10 px-6 py-4 flex justify-between items-center">
        <div className="font-bold text-lg tracking-tight">Siyuan Liu</div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-lg bg-white/5 border border-white/10"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            {isMobileMenuOpen ? (
              <path d="M18 6L6 18M6 6l12 12" />
            ) : (
              <path d="M3 12h18M3 6h18M3 18h18" />
            )}
          </svg>
        </button>
      </div>

      <div className="relative max-w-7xl mx-auto flex flex-col lg:flex-row min-h-screen pt-16 lg:pt-0">
        
        {/* Sidebar */}
        <aside className={`
          lg:sticky lg:top-0 lg:h-screen lg:w-80 flex-shrink-0 
          glass-strong border-r border-white/10 z-40
          fixed inset-0 lg:relative transition-transform duration-300
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}>
          <div className="h-full overflow-y-auto p-6 lg:p-8">
            <profile-sidebar></profile-sidebar>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-12 space-y-16 relative">
          
          {/* Hero Section */}
          <section className="space-y-6 animate-fade-in">
            <div className="space-y-2">
              <h1 className="text-4xl lg:text-5xl font-bold tracking-tight text-slate-100">
                Siyuan (Michelle) <span className="gradient-text">Liu</span>
              </h1>
<p className="text-lg text-slate-400 font-light">
                Undergraduate at PolyU (CS & AI), Research Intern at Tsinghua NLP Lab
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {profileData.hero.badges.map((badge, idx) => (
                <span key={idx} className="px-3 py-1 rounded-full text-xs font-mono font-medium bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">
                  {badge}
                </span>
              ))}
            </div>
            
            <p className="text-slate-400 leading-relaxed max-w-3xl text-lg">
              {profileData.hero.bio}
            </p>
          </section>

          {/* Research Interests */}
          <section className="animate-fade-in" style={{animationDelay: '0.1s'}}>
            <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
              <span className="w-8 h-px bg-indigo-500"></span>
              Research Interests
            </h2>
            <glass-card class="accent" hover>
              <ul className="space-y-3">
                {profileData.researchInterests.map((interest, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-slate-300">
                    <span className="text-indigo-400 mt-1">›</span>
                    <span>{interest}</span>
                  </li>
                ))}
              </ul>
            </glass-card>
          </section>

          {/* Education & Exchange */}
          <section className="grid md:grid-cols-2 gap-6 animate-fade-in" style={{animationDelay: '0.2s'}}>
            <div>
              <h2 className="text-2xl font-bold text-slate-100 mb-4 flex items-center gap-3">
                <span className="w-8 h-px bg-cyan-500"></span>
                Education
              </h2>
              <glass-card hover>
                <div className="font-mono text-cyan-400 text-sm mb-1">{profileData.education.gpa} GPA</div>
                <div className="text-lg font-semibold text-slate-100">{profileData.education.degree}</div>
                <div className="text-slate-400">@ {profileData.education.school}</div>
              </glass-card>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-slate-100 mb-4 flex items-center gap-3">
                <span className="w-8 h-px bg-cyan-500"></span>
                Exchange Programs
              </h2>
              <div className="space-y-3">
                {profileData.exchanges.map((ex, idx) => (
                  <glass-card key={idx} class="cyan" hover padding="1rem">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-100">{ex.school}</span>
                      <span className="font-mono text-xs text-cyan-400 bg-cyan-400/10 px-2 py-1 rounded">{ex.focus}</span>
                    </div>
                  </glass-card>
                ))}
              </div>
            </div>
          </section>

          {/* Core Research Focus */}
          <section className="animate-fade-in" style={{animationDelay: '0.3s'}}>
            <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
              <span className="w-8 h-px bg-indigo-500"></span>
              Core Research Focus
            </h2>
            <div className="grid md:grid-cols-2 gap-4">
              {profileData.coreFocus.map((focus, idx) => (
                <glass-card key={idx} hover class={idx === 2 ? "md:col-span-2 border-l-2 border-l-cyan-500" : ""}>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 flex-shrink-0"></div>
                    <p className="text-slate-300 leading-relaxed">{focus}</p>
                  </div>
                </glass-card>
              ))}
            </div>
          </section>

          {/* Experience Highlights */}
          <section className="animate-fade-in" style={{animationDelay: '0.4s'}}>
            <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
              <span className="w-8 h-px bg-indigo-500"></span>
              Experience Highlights
            </h2>
            <div className="grid md:grid-cols-3 gap-4">
              {profileData.experience.map((exp, idx) => (
                <glass-card key={idx} hover class="h-full">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="font-semibold text-slate-100">{exp.org}</div>
                      <div className="text-sm text-slate-400">{exp.role}</div>
                    </div>
                    <span className="font-mono text-xs text-indigo-400 bg-indigo-400/10 px-2 py-1 rounded">{exp.period}</span>
                  </div>
                  <ul className="space-y-2">
                    {exp.highlights.map((hl, hidx) => (
                      <li key={hidx} className="text-sm text-slate-400 flex items-start gap-2">
                        <span className="text-indigo-500/50 mt-1">•</span>
                        {hl}
                      </li>
                    ))}
                  </ul>
                </glass-card>
              ))}
            </div>
          </section>

          {/* Research Timeline & Publications */}
          <section className="animate-fade-in" style={{animationDelay: '0.5s'}}>
            <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
              <span className="w-8 h-px bg-cyan-500"></span>
              Research Timeline & Publications
            </h2>
            
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Timeline */}
              <div className="lg:col-span-1">
                <research-timeline selected-year={selectedTimelineYear || ''}></research-timeline>
              </div>
              
              {/* Publications */}
              <div className="lg:col-span-2 space-y-4">
                {filteredPublications.length === 0 ? (
                  <glass-card class="text-center py-12 text-slate-500">
                    No publications for selected year. Click "Current" or another year to filter.
                  </glass-card>
                ) : (
                  filteredPublications.map((pub) => (
                    <publication-card
                      key={pub.id}
                      title={pub.title}
                      venue={pub.venue}
                      year={pub.year}
                      tags={pub.tags.join(',')}
                      expanded={expandedPubs.has(pub.id) ? 'true' : 'false'}
                      onclick={() => togglePub(pub.id)}
                    >
                      {pub.contributions.map((contrib, idx) => (
                        <li key={idx} slot="contribution">{contrib}</li>
                      ))}
                    </publication-card>
                  ))
                )}
              </div>
            </div>
          </section>

          {/* Featured Models */}
          <section className="animate-fade-in" style={{animationDelay: '0.6s'}}>
            <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
              <span className="w-8 h-px bg-indigo-500"></span>
              Featured Models / Spaces
            </h2>
            <div className="grid md:grid-cols-3 gap-4">
              {profileData.models.map((model, idx) => (
                <glass-card key={idx} hover class="group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500/20 to-cyan-500/20 flex items-center justify-center border border-white/10 group-hover:border-indigo-500/30 transition-colors">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" className="text-indigo-400">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-100">{model.name}</div>
                      <div className="text-xs text-slate-500 font-mono">{model.status}</div>
                    </div>
                  </div>
                  <p className="text-sm text-slate-400 mb-4">{model.desc}</p>
                  <button className="w-full py-2 px-4 rounded-lg bg-white/5 border border-white/10 text-sm font-mono text-slate-300 hover:bg-indigo-500/10 hover:border-indigo-500/30 hover:text-indigo-300 transition-all flex items-center justify-center gap-2">
                    <span>View on Hugging Face</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M7 17L17 7M17 7H7M17 7V17"/>
                    </svg>
                  </button>
                </glass-card>
              ))}
            </div>
          </section>
          {/* Awards & Tech Stack */}
          <section className="grid md:grid-cols-2 gap-8 animate-fade-in" style={{animationDelay: '0.6s'}}>
<div>
              <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
                <span className="w-8 h-px bg-cyan-500"></span>
                Awards
              </h2>
              <glass-card>
                <ul className="space-y-3">
                  {profileData.awards.map((award, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-slate-300">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" className="text-yellow-500 flex-shrink-0">
                        <circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>
                      </svg>
                      <span>{award}</span>
                    </li>
                  ))}
                </ul>
              </glass-card>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-3">
                <span className="w-8 h-px bg-cyan-500"></span>
                Technical Stack
              </h2>
              <glass-card>
                <div className="space-y-4">
                  <div>
                    <div className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">Languages</div>
                    <div className="flex flex-wrap gap-2">
                      {profileData.techStack.languages.map((lang) => (
                        <span key={lang} className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 font-mono text-sm text-cyan-400">{lang}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">ML Frameworks</div>
                    <div className="flex flex-wrap gap-2">
                      {profileData.techStack.ml.map((tool) => (
                        <span key={tool} className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 font-mono text-sm text-indigo-400">{tool}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">Tooling</div>
                    <div className="flex flex-wrap gap-2">
                      {profileData.techStack.tools.map((tool) => (
                        <span key={tool} className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 font-mono text-sm text-slate-300">{tool}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </glass-card>
            </div>
          </section>

          {/* Footer */}
          <footer className="pt-12 pb-6 border-t border-white/10 text-center text-slate-500 text-sm">
            <p>© 2025 Siyuan (Liu) Liu. Built for Hugging Face Spaces.</p>
            <p className="mt-2 font-mono text-xs">Seeking Summer Research Opportunities</p>
          </footer>
        </main>
      </div>
    </div>
  );
}

// Render the app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);